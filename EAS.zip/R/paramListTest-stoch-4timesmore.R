# this is a parameter list for keeping record of parameters and easy manipulation
# srr = self replication request
paramList <- list(
  miningModule = list(
    name = "miningModule",
    processTime = list(
      min = 7.99,
      mode = 8,
      max  = 12.01
    ),
    capacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  oreStorage = list(
    name = "rawStorage",
    initialCapacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  processingModule = list(
    name = "processingModule",
    processingTime = list(
      min = 12.99,
      mode = 16,
      max  = 20.01
    ),
    capacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  refinedStorage = list(
    name = "refinedStorage",
    initialCapacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  recyclingModule = list(
    name = "recyclingModule",
    processingTime = list(
      min = 12.99,
      mode = 16,
      max  = 20.01
    ),
    capacity = 5,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  printerRobot = list(
    name = "printingRobot",
    processingTime = list(
      min = 16.99,
      mode = 20,
      max  = 25.01
    ),
    capacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  shellStorage = list(
    name = "shellStorage",
    initialCapacity = 100000,
    srr = 0,
    lifeTime = list(
      min = 9900000,
      mode = 10000000,
      max = 1000000000
    )
  ),
  manufacturingModule = list(
    name = "manufacturingModule",
    processingTime = list(
      min = 8.99,
      mode = 12,
      max  = 16.01
    ),
    capacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  equipmentStorage = list(
    name = "equipmentStorage",
    initialCapacity = 5,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  assemblyRobot = list(
    name = "assemblyRobot",
    processingTime = list(
      min = 8.99,
      mode = 12,
      max  = 16.01
    ),
    capacity = 10,
    srr = 0,
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    )
  ),
  habitationModule = list(
    name = "habitationModule",
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    ),
    population = 25
  ),
  bioModule = list(
    name = "bioModule",
    lifeTime = list(
      min = 75,
      mode = 100,
      max = 200
    ),
    population = 25
  ),
  entity = list(
    ore = list(
      name = "rawMaterial",
      initial.pop = 1,
      live.pop = 0
    ),
    refinedMaterial = list(
      name = "refinedMaterial",
      initial.pop = 1,
      live.pop = 0
    ),
    shell = list(
      name = "shell",
      initial.pop = 1,
      live.pop = 0
    ),
    equipment = list(
      name = "equipment",
      initial.pop = 1,
      live.pop = 0
    ),
    habitation = list(
      name = "habitationModule",
      initial.pop = 25,
      live.pop = 0
    ),
    lifeSupport = list(
      name = "bioModule",
      initial.pop = 25,
      live.pop = 0
    ),
    blankModule = list(
      name = "blankModule",
      initial.pop = 0,
      live.pop = 0
    )
  ),
  resource = list(
    asteroid = list(
      name = "asteroid",
      initial.pop = 5000,
      live.pop = 0
    ) 
  ),
  population = list(
    human = list(
      name = "human",
      initial.pop = 150,
      modelParam = list(
        max.occupancy = 6,
        delta = 0.015/12
      )
    )
  )
)
