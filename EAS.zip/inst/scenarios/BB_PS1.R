# initialize storage / asteroid resource parameters
paramList$resource$asteroid$initial.pop <- 5000
paramList$oreStorage$initialCapacity <- 10
paramList$refinedStorage$initialCapacity <- 10
paramList$shellStorage$initialCapacity <- 1
paramList$equipmentStorage$initialCapacity <- 5
# initialize entities in the system
paramList$entity$ore$initial.pop <- 10
paramList$entity$refinedMaterial$initial.pop <- 10
paramList$entity$shell$initial.pop <- 0
paramList$entity$equipment$initial.pop <- 0
paramList$entity$habitation$initial.pop <- 25
paramList$entity$lifeSupport$initial.pop <- 25
paramList$population$human$initial.pop <- 150
# initialize srr
paramList$miningModule$srr <- 1
paramList$oreStorage$srr <- 1
paramList$processingModule$srr <- 1
paramList$refinedStorage$srr <- 1
paramList$printerRobot$srr <- 1
paramList$shellStorage$srr <- 1
paramList$manufacturingModule$srr <- 1
paramList$equipmentStorage$srr <- 1
paramList$assemblyRobot$srr <- 1
paramList$recyclingModule$srr <- 1
# initialize resource capacity
paramList$miningModule$capacity <- 10
paramList$processingModule$capacity <- 10
paramList$recyclingModule$capacity <- 10
paramList$printerRobot$capacity <- 2
paramList$manufacturingModule$capacity <- 10
paramList$assemblyRobot$capacity <- 10