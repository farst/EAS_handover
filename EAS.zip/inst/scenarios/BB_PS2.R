# initialize storage / asteroid resource parameters
paramList$resource$asteroid$initial.pop <- 1000
paramList$oreStorage$initialCapacity <- 4
paramList$refinedStorage$initialCapacity <- 4 
paramList$shellStorage$initialCapacity <- 4
paramList$equipmentStorage$initialCapacity <- 4
# initialize entities in the system
paramList$entity$ore$initial.pop <- 4
paramList$entity$refinedMaterial$initial.pop <- 4
paramList$entity$shell$initial.pop <- 4
paramList$entity$equipment$initial.pop <- 4
paramList$entity$habitation$initial.pop <- 16
paramList$entity$lifeSupport$initial.pop <- 16
paramList$population$human$initial.pop <- 100
# initialize srr
paramList$miningModule$srr <- 1
paramList$oreStorage$srr <- 1
paramList$processingModule$srr <- 1
paramList$refinedStorage$srr <- 1
paramList$printerRobot$srr <- 1
paramList$shellStorage$srr <- 1
paramList$manufacturingModule$srr <- 1
paramList$equipmentStorage$srr <- 1
paramList$assemblyRobot$srr <- 1
paramList$recyclingModule$srr <- 1
# initialize resource capacity
paramList$miningModule$capacity <- 4
paramList$processingModule$capacity <- 4
paramList$recyclingModule$capacity <- 2
paramList$printerRobot$capacity <- 4
paramList$manufacturingModule$capacity <- 4
paramList$assemblyRobot$capacity <- 2