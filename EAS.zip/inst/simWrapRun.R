# load libraries
library(simmer, quietly = TRUE)
library(plotly, quietly = TRUE)
library(EnvStats, quietly = TRUE)
library(data.table, quietly = TRUE)
# source functions
source("R/fun_modules.R", echo = FALSE)
# source parameters
source("R/paramListTest-stoch.R", echo = FALSE)
#source("inst/scenarios/BB_PS1.R")
# source model
source("inst/trajectories-SR-stoch.R", echo = FALSE)

simWrapSeedVar <- function(seed){
  EAS <<- simmer()
  set.seed(seed)
  reset(EAS)
  EAS %>% 
    add_generator("time", sandGlass, at(0)) %>% 
    add_generator("population", population, at(0)) %>% 
    add_generator("asteroid_dust", miningTraj, when_activated(1)) %>%
    add_resource(paramList$miningModule$name, paramList$miningModule$capacity) %>% 
    add_generator("ore", processingTraj, when_activated(1)) %>% 
    add_resource(paramList$processingModule$name, paramList$processingModule$capacity, queue_size = Inf) %>% 
    add_generator("refined_material_pri", printingTraj, when_activated(1)) %>% 
    add_resource(paramList$printerRobot$name, paramList$printerRobot$capacity) %>% 
    add_generator("refined_material_equi", manufacturingTraj, when_activated(1)) %>% 
    add_resource(paramList$manufacturingModule$name, paramList$manufacturingModule$capacity) %>%
    add_generator("assembly_order", assemblingTraj, when_activated(1)) %>% 
    add_resource(paramList$assemblyRobot$name, paramList$assemblyRobot$capacity) %>%
    add_resource(paramList$recyclingModule$name, paramList$recyclingModule$capacity)
  EAS %>% run(20000, progress=progress::progress_bar$new()$update)
  EAS
}

seeds <- seq(1, 5)
seeds <- seeds*100

res <- lapply(seeds, function(seed){
  simWrapSeedVar(seed)
})

DTL <- lapply(seq(1, length(res)), function(i){
  DT <- as.data.table(res[i] %>% get_mon_attributes())
  DT[key == "human.pop", value := round(value)]
  DT
})

names(DTL) <- seeds
DTL <- rbindlist(DTL, use.names = T, idcol = "seed")

saveRDS(DTL, file = "BB_base_run_1600yr_5itrations.rds")

# DTL <- readRDS("BB_PS1.rds"); sc <- 1
# DTL <- readRDS("BB_PS2.rds"); sc <- 2
# DTL <- readRDS("BB_PS3.rds"); sc <- 3
# DTL <- readRDS("BB_PS2-200Seeds.rds"); sc <- "BB-200"
# DTL <- readRDS("BB_PS3.rds"); sc <- "base_run"

DTL[, rndTime := round(time, 0)]
DTL[, ':='(meanVal = mean(value), maxVal = max(value), minVal = min(value)), by = .(key, rndTime, seed)]
DTL[, ':='(meanVal = mean(meanVal), maxVal = max(maxVal), minVal = min(minVal)), by = .(key, rndTime)]
DTL[, ':='(medianVal = median(value, na.rm = T), sdVal = sd(value, na.rm = T)), by = .(key, rndTime)]
DTmargin <- unique(DTL[, .(rndTime, key, meanVal, maxVal, minVal)])
vois <- c("human.pop", "habitationModule.pop", "asteroid.pop", "occupancy.kpi")
ggplot(DTL[key %in% vois])+
  geom_path(aes(x=time, y=value, group=seed), alpha = 0.3)+
  #geom_smooth(aes(x=rndTime, y = medianVal), color = "blue")+
  #geom_smooth(aes(x=rndTime, y = medianVal+sdVal), color = "red")+
  #geom_smooth(aes(x=rndTime, y = medianVal-sdVal), color = "red")+
  #geom_smooth(data = DTmargin[key %in% vois], aes(x=rndTime, y=maxVal), alpha = 0.5, color = "red")+
  #geom_smooth(data = DTmargin[key %in% vois], aes(x=rndTime, y=minVal), alpha = 0.5, color = "red")+
  #geom_smooth(data = DTmargin[key %in% vois], aes(x=rndTime, y=meanVal), color = "blue")+
  facet_wrap(~key, scales = "free")+
  ggtitle(paste0("200 iterations; 2400 days; basic behaviour, parameter set ", sc))

popDTL <- DTL[key == "human.pop"]
popDTL <- DTL[key == "habitationModule.pop"]
popDTL <- DTL[key == "asteroid.pop"]
popDTL <- DTL[key == "occupancy.kpi"]
popDTL[, seed := as.numeric(seed)]
ggplot(popDTL)+geom_path(aes(x=time, y=value, group=seed), alpha = 0.3)+
  ggtitle(paste0("20 iterations; 10000 days; basic behaviour, parameter set ", sc))+
  geom_vline(aes(xintercept= 500), color = "orange")+
  geom_vline(aes(xintercept= 8000), color = "red")


unique(DTL$key)

factoryChain <- c("rawStorage.pop", "refinedStorage.pop", "equipmentStorage.pop", "miningModule.pop",
                  "processingModule.pop", "recyclingModule.pop", "printingRobot.pop", "manufacturingModule.pop",
                  "assemblyRobot.pop")

factoryChain <- c("miningModule.pop",
                  "processingModule.pop", "recyclingModule.pop", "printingRobot.pop", "manufacturingModule.pop",
                  "assemblyRobot.pop")

facDT <- DTL[key %in% factoryChain]
facSizeDT <- facDT[, .(sizeOfFactory = sum(value)), by = .(time, seed)]

ggplot()+
  geom_boxplot(data = facSizeDT, aes(x=time, y=sizeOfFactory, group=seed), alpha = 0.1)

ggplot()+
  geom_line(data = facDT, aes(x=time, y=value, group = seed), alpha = 0.3)+
  facet_wrap(~key)

materialUnits <- c("asteroid.pop", "shell.pop", "rawMaterial.pop", "refinedMaterial.pop"
                   , "equipment.pop")

ggplot()+
  geom_line(data = DTL[key %in% materialUnits]
            , aes(x=time, y=value, group = seed), alpha = 0.3)+
  facet_wrap(~key, scales = "free_y")
