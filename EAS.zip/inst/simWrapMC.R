library(simmer, quietly = TRUE)
library(plotly, quietly = TRUE)
library(EnvStats, quietly = TRUE)
library(data.table, quietly = TRUE)
source("R/fun_modules.R", echo = FALSE)
source("inst/monteCarlo.R")
source("inst/trajectories-SR.R", echo = FALSE)


simWrapMC <- function(i){
  EAS <<- simmer()
  source("R/paramList.R", echo = FALSE)
  mcDoping <- function(i, mcParDT = mcParDT)
  source("inst/trajectories-SR.R", echo = FALSE)
  reset(EAS)
  EAS %>% 
    add_generator("time", sandGlass, at(0)) %>% 
    add_generator("population", population, at(0)) %>% 
    add_generator("asteroid_dust", miningTraj, when_activated(1)) %>%
    add_resource(paramList$miningModule$name, paramList$miningModule$capacity) %>% 
    add_generator("ore", processingTraj, when_activated(1)) %>% 
    add_resource(paramList$processingModule$name, paramList$processingModule$capacity, queue_size = Inf) %>% 
    add_generator("refined_material_pri", printingTraj, when_activated(1)) %>% 
    add_resource(paramList$printerRobot$name, paramList$printerRobot$capacity) %>% 
    add_generator("refined_material_equi", manufacturingTraj, when_activated(1)) %>% 
    add_resource(paramList$manufacturingModule$name, paramList$manufacturingModule$capacity) %>%
    add_generator("assembly_order", assemblingTraj, when_activated(1)) %>% 
    add_resource(paramList$assemblyRobot$name, paramList$assemblyRobot$capacity) %>%
    add_resource(paramList$recyclingModule$name, paramList$recyclingModule$capacity)
  EAS %>% run(10000, progress=progress::progress_bar$new()$update)
  EAS
}

res <- lapply(seq(1, nrow(mcParDT)), function(it){
  simWrapMC(i = it)
})

DTL <- lapply(seq(1, length(res)), function(i){
  DT <- as.data.table(res[i] %>% get_mon_attributes())
  DT[key == "human.pop", value := round(value)]
  DT
})

names(DTL) <- seq(1, nrow(mcParDT))
DTL <- rbindlist(DTL, use.names = T, idcol = "rep")

DTL[, rndTime := round(time)]
DTL[, ':='(meanVal = mean(value), maxVal = max(value), minVal = min(value)), by = .(key, rndTime, rep)]
DTL[, ':='(meanVal = mean(meanVal), maxVal = max(maxVal), minVal = min(minVal)), by = .(key, rndTime)]
DTmargin <- unique(DTL[, .(rndTime, key, meanVal, maxVal, minVal)])
vois <- c("human.pop", "habitationModule.pop", "asteroid.pop", "occupancy.kpi")
ggplot(DTL[key %in% vois])+
  geom_path(aes(x=time, y=value, group=rep), alpha = 0.3)+
  geom_smooth(data = DTmargin[key %in% vois], aes(x=rndTime, y=maxVal), alpha = 0.5, color = "red")+
  geom_smooth(data = DTmargin[key %in% vois], aes(x=rndTime, y=minVal), alpha = 0.5, color = "red")+
  geom_smooth(data = DTmargin[key %in% vois], aes(x=rndTime, y=meanVal), color = "blue")+
  facet_wrap(~key, scales = "free")+
  ggtitle(paste0(nrow(mcParDT), " samples; 10000 days"))
