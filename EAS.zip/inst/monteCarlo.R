mcParGen <- function(mcSamapleSize, variation) {
  data.table(# initialize storage / asteroid resource parameters
    asteroid_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*10000, min = (1-variation)*10000)),
    oreStorage_initialCapacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    refinedStorage_initialCapacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    shellStorage_initialCapacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    equipmentStorage_initialCapacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    # initialize entities in the system
    entity_ore_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    entity_refinedMaterial_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    entity_shell_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    entity_equipment_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    entity_habitation_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*42, min = (1-variation)*42)),
    entity_lifeSupport_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*84, min = (1-variation)*84)),
    population_human_initial.pop = round(runif(n = mcSamapleSize, max = (1+variation)*500, min = (1-variation)*500)),
    # initialize resource capacity
    miningModule_capacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    processingModule_capacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    recyclingModule_capacity = round(runif(n = mcSamapleSize, max = (1+variation)*2, min = (1-variation)*2)),
    printerRobot_capacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    manufacturingModule_capacity = round(runif(n = mcSamapleSize, max = (1+variation)*4, min = (1-variation)*4)),
    assemblyRobot_capacity = round(runif(n = mcSamapleSize, max = (1+variation)*2, min = (1-variation)*2))
  )
}

mcParDT <- mcParGen(mcSamapleSize = 10, variation = 0.3)
names(mcParDT)

mcDoping <- function(i, mcParDT) {
  # initialize storage / asteroid resource parameters
  paramList$resource$asteroid$initial.pop <<- mcParDT[i,1]
  paramList$oreStorage$initialCapacity <<- mcParDT[i,2]
  paramList$refinedStorage$initialCapacity <<- mcParDT[i,3]
  paramList$shellStorage$initialCapacity <<- mcParDT[i,4]
  paramList$equipmentStorage$initialCapacity <<- mcParDT[i,5]
  # initialize entities in the system
  paramList$entity$ore$initial.pop <<- mcParDT[i,6]
  paramList$entity$refinedMaterial$initial.pop <<- mcParDT[i,7]
  paramList$entity$shell$initial.pop <<- mcParDT[i,8]
  paramList$entity$equipment$initial.pop <<- mcParDT[i,9]
  paramList$entity$habitation$initial.pop <<- mcParDT[i,10]
  paramList$entity$lifeSupport$initial.pop <<- mcParDT[i,11]
  paramList$population$human$initial.pop <<- mcParDT[i,12]
  # initialize resource capacity
  paramList$miningModule$capacity <<- mcParDT[i,13]
  paramList$processingModule$capacity <<- mcParDT[i,14]
  paramList$recyclingModule$capacity <<- mcParDT[i,15]
  paramList$printerRobot$capacity <<- mcParDT[i,16]
  paramList$manufacturingModule$capacity <<- mcParDT[i,17]
  paramList$assemblyRobot$capacity <<- mcParDT[i,18]
}